# 📻 eQSL Downloader DXCC v2.1

**Téléchargez automatiquement vos cartes QSL depuis eQSL.cc**

Développé par **F4LPS** et **F4LCL** - 73 📻

---

## 🚀 Démarrage rapide

1. **Double-cliquez** sur `eQSL_Downloader.exe`
2. **Choisissez votre langue** en haut à droite
3. **Entrez vos identifiants** eQSL.cc
4. **Configurez vos options** et cliquez sur "Démarrer"
5. **Vos QSL** sont téléchargées et organisées automatiquement !

> ⚠️ **Première utilisation** : Le démarrage peut prendre 10-20 secondes (c'est normal)

---

## ✨ Fonctionnalités

### 🆕 Nouveautés v2.1

✅ **Cache global unifié** - INBOX + ARCHIVE 100% cohérents  
✅ **Visionneuse QSL intégrée** avec filtres par pays et indicatifs  
✅ **Carte du monde interactive** HTML de vos contacts  
✅ **Rapports statistiques détaillés** (bandes, modes, années)  
✅ **Recherche d'indicatifs** dans vos QSL  
✅ **Export Google Earth** (KML) avec drapeaux de 80+ pays  
✅ **Organisation flexible** : par pays, bande, mode ou année  
✅ **Statut DXCC** - Visualisez vos pays confirmés  

### Fonctionnalités de base

✅ **6 langues** : Français, English, Deutsch, Italiano, Português, Español  
✅ **1300+ préfixes DXCC** reconnus (90% de couverture mondiale)  
✅ **Organisation automatique** par pays dans des dossiers  
✅ **Détection intelligente des doublons** - évite les téléchargements multiples  
✅ **Filtres avancés** : Inbox, Archives, dates, pays  
✅ **Statistiques en temps réel**  
✅ **Téléchargement rapide** : 60-80 QSL/minute  

---

## 📋 Avant de commencer

**Vous avez besoin de :**
- ✅ Un compte actif sur **eQSL.cc**
- ✅ Votre **Indicatif** (callsign)
- ✅ Votre **Mot de passe** eQSL
- ✅ Votre **QTH Nickname** (trouvez-le sur eQSL.cc → My Profile)
- ✅ Une **connexion Internet**

---

## 🖥️ Utilisation

### 1️⃣ Identifiants

Remplissez vos informations eQSL :
- **Indicatif** : Votre callsign (ex: F4LPS)
- **Mot de passe** : Votre mot de passe eQSL.cc
- **QTH Nickname** : Visible dans votre profil eQSL
- ☑️ **Cochez** "Enregistrer les identifiants" pour ne plus les ressaisir

### 2️⃣ Options de téléchargement

**📥 INBOX (Boîte de réception)**
- ✅ Inclure confirmées
- ❓ Inclure non confirmées

**🗄️ ARCHIVES**
- ✅ Inclure confirmées
- ❓ Inclure non confirmées

> 💡 **Astuce** : Pour un téléchargement complet initial, cochez INBOX + ARCHIVES confirmées

**🌍 Filtrer par pays**
- Choisissez un pays spécifique
- Ou laissez "Tous les pays" pour une organisation automatique

**📅 Période**
- Date début : AAAAMMJJ (ex: 20240101)
- Date fin : AAAAMMJJ (ex: 20241231)

**📁 Dossier destination**
- Par défaut : `QSL_Cards` à côté du programme
- Cliquez sur "Parcourir" pour choisir un autre dossier

### 3️⃣ Téléchargement

1. Cliquez sur **🚀 DÉMARRER LE TÉLÉCHARGEMENT**
2. Suivez la progression en temps réel
3. Les statistiques s'actualisent automatiquement
4. Cliquez sur **⏹️ ARRÊTER** pour interrompre

### 4️⃣ Fonctions avancées (Colonne droite)

**📊 Générer rapport statistique**
- Statistiques complètes par pays, bandes, modes, années
- Graphiques détaillés
- Export HTML consultable

**🖼️ Visionneuse QSL**
- Parcourez toutes vos QSL
- Filtres par pays et indicatif
- Navigation facile avec aperçu

**🗺️ Carte du monde**
- Carte interactive HTML de vos contacts
- Couleurs selon nombre de QSL par pays
- Visualisation géographique de votre activité

**🔍 Rechercher un indicatif**
- Trouvez rapidement toutes les QSL d'un indicatif
- Affiche pays, date, bande, mode

**🌍 Export Google Earth**
- Fichier KML avec drapeaux de 80+ pays
- Visualisation 3D de vos contacts
- Compatible Google Earth

**📁 Organiser QSL**
- Par bande (10M, 20M, 40M, etc.)
- Par mode (SSB, FT8, CW, etc.)
- Par année

**📈 Statut DXCC**
- Liste des pays confirmés
- Progression vers awards
- Statistiques DXCC

### 5️⃣ Résultats

Vos QSL sont organisées dans des dossiers par pays :

```
QSL_Cards/
├── .cache/
│   └── qsl_global.json      (Cache global - NE PAS SUPPRIMER)
├── .cache_par_pays/
│   ├── France_cache.json
│   ├── USA_cache.json
│   └── ...
├── France/
│   ├── F1ABC_20240615_1234_20M_SSB.jpg
│   └── ...
├── USA/
│   ├── W1ABC_20241120_0856_40M_FT8.jpg
│   └── ...
├── Puerto Rico/
├── Allemagne/
├── Japon/
├── Autres/
├── Par_Bande/               (Si organisé par bande)
├── Par_Mode/                (Si organisé par mode)
└── Par_Année/               (Si organisé par année)
```

**Format des fichiers** : `INDICATIF_DATE_HEURE_BANDE_MODE.jpg`

**Exemple** : `F4ABC_20241115_1430_20M_SSB.jpg`

---

## ⚠️ Avertissement Antivirus

### C'est normal !

Votre antivirus peut afficher une alerte de type :
- "Fichier non reconnu"
- "Éditeur inconnu"
- "Menace potentielle"

**C'est un FAUX POSITIF** très courant avec les programmes Python compilés.

### Pourquoi ?

Les exécutables créés avec PyInstaller sont souvent signalés par les antivirus car :
- Le programme n'a pas de signature numérique payante (~300€/an)
- Les antivirus sont prudents avec les nouveaux fichiers
- C'est une protection normale

### Que faire ?

**Option 1** : Ajouter une exception dans votre antivirus
1. Ouvrez votre antivirus (Windows Defender, Avast, etc.)
2. Ajoutez `eQSL_Downloader.exe` aux exceptions/exclusions
3. Relancez le programme

**Option 2** : Analyser le fichier en ligne
- VirusTotal : https://www.virustotal.com
- Uploadez le fichier pour une analyse multi-antivirus
- Vous verrez que la majorité le reconnaît comme sûr

**Option 3** : Utiliser le code source
- Téléchargez le code source Python
- Lancez avec `python eqsl_downloader_gui.py`
- Contact : developpement@lesf4.fr

### 🔒 Sécurité garantie

✅ **Code open source** : Transparence totale  
✅ **Aucune collecte de données**  
✅ **Aucune transmission à des tiers**  
✅ **Connexion HTTPS sécurisée** avec eQSL.cc  
✅ **Testé par F4LPS et F4LCL** et la communauté radioamateur  

---

## ❓ Problèmes courants

### Le programme ne démarre pas
- ⏳ **Première utilisation** : Patientez 10-20 secondes
- 🛡️ **Antivirus** : Ajoutez une exception
- 🔄 **Redémarrage** : Fermez et relancez

### Erreur d'authentification
- ✅ Vérifiez votre indicatif
- ✅ Vérifiez votre mot de passe
- ✅ Vérifiez votre QTH Nickname sur eQSL.cc
- ✅ Testez votre connexion sur le site eQSL.cc

### Erreur "Accès refusé" au dossier
- 📁 Choisissez un autre dossier de destination
- 🔓 Vérifiez les permissions d'écriture
- 👮 Lancez en tant qu'administrateur (clic droit sur l'exe)

### Aucune QSL trouvée
- ✅ Vérifiez que vous avez des QSL sur eQSL.cc
- ✅ Vérifiez qu'au moins une option est cochée (Inbox ou Archive)
- ✅ Vérifiez vos filtres de dates
- ✅ Essayez sans filtre de pays

### Les QSL sont téléchargées en double
- ⚠️ **NE SUPPRIMEZ PAS** le fichier `qsl_global.json`
- Ce fichier évite automatiquement les doublons
- Le système de cache v2.1 garantit la cohérence INBOX + ARCHIVE

### Les rapports affichent un nombre différent
- ✅ Le cache global garantit maintenant la cohérence totale
- ✅ INBOX + ARCHIVE = Total correct partout
- ✅ Si problème persiste, réinitialisez le cache et re-téléchargez

---

## 💬 Support & Communauté

### Discord - Les F4 HAM RADIO
**Rejoignez notre communauté !**

Une communauté active de radioamateurs pour :
- ✅ Poser vos questions
- ✅ Partager vos retours
- ✅ Proposer des améliorations
- ✅ Discuter radioamateur

### Email
📧 **developpement@lesf4.fr**

---

## 📊 Exemples d'utilisation

### Télécharger toutes les nouvelles QSL
```
✅ Inbox : Confirmées + Non confirmées
❌ Archives : Aucune
🌍 Pays : Tous les pays
```
**➜ Organisation automatique par pays, sans doublons**

---

### QSL françaises de 2024 uniquement
```
✅ Inbox : Confirmées + Non confirmées
❌ Archives : Aucune
🌍 Pays : France
📅 Date début : 20240101
📅 Date fin : 20241231
```
**➜ Dossiers France/ et France-TM/ avec QSL 2024**

---

### Récupérer TOUT (Inbox + Archives)
```
✅ Inbox : Confirmées + Non confirmées
✅ Archives : Confirmées + Non confirmées
🌍 Pays : Tous les pays
```
**➜ Collection complète organisée par pays, cache global cohérent**

---

### Créer une carte du monde de mes contacts
```
1. Téléchargez vos QSL (INBOX + ARCHIVE)
2. Cliquez sur "🗺️ Carte du monde"
3. Ouvrez le fichier HTML généré
```
**➜ Carte interactive avec statistiques par pays**

---

### Exporter vers Google Earth
```
1. Téléchargez vos QSL
2. Cliquez sur "🌍 Export Google Earth"
3. Ouvrez le fichier KML dans Google Earth
```
**➜ Visualisation 3D avec drapeaux de 80+ pays**

---

## 🌍 Pays supportés

**Plus de 1300 préfixes DXCC** reconnus automatiquement (90% de couverture mondiale) :

🇫🇷 France • 🇩🇪 Allemagne • 🇮🇹 Italie • 🇪🇸 Espagne • 🇬🇧 Royaume-Uni • 🇺🇸 USA • 🇨🇦 Canada • 🇯🇵 Japon • 🇨🇳 Chine • 🇧🇷 Brésil • 🇦🇷 Argentine • 🇦🇺 Australie • 🇷🇺 Russie • 🇺🇦 Ukraine • 🇵🇱 Pologne • 🇹🇷 Turquie • 🇮🇳 Inde • 🇮🇩 Indonésie • 🇹🇭 Thaïlande • 🇿🇦 Afrique du Sud • 🇵🇷 Puerto Rico • 🇰🇿 Kazakhstan • 🇰🇬 Kyrgyzstan • Et bien plus...

**Entités spéciales** : Irlande du Nord (2I0), Monaco (3A), Vatican (HV), Corse (TK), Écosse (MM/MS/GM)...

**USA complet** : K/N/W A-Z (78 préfixes)

---

## 📝 Fichiers générés

Le programme crée automatiquement :

| Fichier | Description | Supprimer ? |
|---------|-------------|-------------|
| `QSL_Cards/` | Dossier avec vos QSL | ❌ Non |
| `.cache/qsl_global.json` | Cache global unifié v2.1 | ❌ **JAMAIS** |
| `.cache_par_pays/` | Cache par pays (compatibilité) | ⚠️ Optionnel |
| `Rapport_Statistiques_*.html` | Rapports générés | ✅ Oui (optionnel) |
| `Carte_Monde_*.html` | Cartes générées | ✅ Oui (optionnel) |
| `Google_Earth_*.kml` | Export KML | ✅ Oui (optionnel) |
| `eqsl_credentials.json` | Identifiants sauvegardés | ⚠️ Si désiré |

> ⚠️ **Important** : Ne supprimez JAMAIS le fichier `qsl_global.json` car il garantit la cohérence et évite les doublons !

---

## 🎉 Remerciements

- **eQSL.cc** pour leur service
- **La communauté radioamateur** pour les retours et tests
- **Tous les OMs** qui utilisent ce programme
- **Claude (Anthropic AI)** pour l'assistance au développement

---

## 📜 Licence

**Licence GPL v3** - Utilisation libre 

Ce programme est :
- ✅ **Open Source** : Code source disponible
- ✅ **Gratuit** : Aucun coût, aucune limitation
- ✅ **Modifiable** : Vous pouvez l'adapter
- ✅ **Redistribuable** : Partagez-le librement

---

## 🔗 Liens

- **Discord Les F4** : Rejoignez notre communauté !
- **Email** : developpement@lesf4.fr
- **eQSL.cc** : https://www.eqsl.cc

---

## 📌 Version

**eQSL Downloader v2.1** - Novembre 2025

### Nouveautés de cette version :

**🆕 Architecture cache global**
- ✨ Fichier unique `qsl_global.json` (source unique de vérité)
- ✨ INBOX + ARCHIVE 100% cohérents dans tous les rapports
- ✨ Fusion automatique intelligente
- ✨ Anti-doublons parfait par hash QSL

**🆕 Visualisation et rapports**
- 📊 Rapports statistiques HTML détaillés (pays, bandes, modes, années)
- 🖼️ Visionneuse QSL intégrée avec filtres
- 🗺️ Carte du monde interactive HTML
- 🔍 Recherche d'indicatifs rapide
- 🌍 Export Google Earth (KML) avec drapeaux 80+ pays
- 📈 Statut DXCC avec progression

**🆕 Organisation avancée**
- 📁 Organisation par bande (10M, 20M, 40M, etc.)
- 📁 Organisation par mode (SSB, FT8, CW, etc.)
- 📁 Organisation par année

**🆕 Couverture DXCC étendue**
- 🌍 1300+ préfixes (90% de couverture mondiale)
- 🇺🇸 USA complet K/N/W A-Z (78 préfixes)
- 🇵🇷 Puerto Rico corrigé (KP3, KP4, WP3, WP4)
- 🇰🇿 Kazakhstan (UN, UO, UP, UQ)
- 🇰🇬 Kyrgyzstan (EX)

**🔧 Améliorations techniques**
- ✨ Interface 2 colonnes moderne
- ✨ Vitesse optimisée 60-80 QSL/minute
- ✨ Logs détaillés en temps réel
- ✨ Gestion mémoire améliorée
- ✨ Stabilité totale validée

---

**73 et bon DX ! 📻**

*Développé avec ❤️ pour la communauté radioamateur*

**F4LPS & F4LCL**

---

*README.txt - Version 2.1 - Novembre 2025*
